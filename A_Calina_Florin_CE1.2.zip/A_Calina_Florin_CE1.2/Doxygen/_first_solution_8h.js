var _first_solution_8h =
[
    [ "a_list_node", "structa__list__node.html", "structa__list__node" ],
    [ "dijkstra", "_first_solution_8h.html#acde593414bc4a326ac174215d1492fbc", null ],
    [ "graph_bfs_2", "_first_solution_8h.html#aaaa929f6907781cc53cf68e821ee48f7", null ],
    [ "graph_dfs", "_first_solution_8h.html#aeb5b758408b6950df124c61df4a3c71e", null ],
    [ "graph_dfs_2", "_first_solution_8h.html#ae1934354751d73b809a430c9bbfc8412", null ],
    [ "minDistance", "_first_solution_8h.html#a8d33c649f1a9356c3b27e7fb9348ce34", null ],
    [ "pop_begining_list", "_first_solution_8h.html#a396ce4e8a887e39ece930de9dbd5e24e", null ],
    [ "pop_end_list", "_first_solution_8h.html#ab76870444edc8084641fa222cf75f04f", null ],
    [ "printAlternativPath", "_first_solution_8h.html#a85772f93bf912e49d01a8da4bbff9f5d", null ],
    [ "printAlternativPath_2", "_first_solution_8h.html#a9c884c9d2b30f014efc11efc17b30d83", null ],
    [ "printPath", "_first_solution_8h.html#afdc35fb0afa5863031adc93bed579e39", null ],
    [ "printSolution", "_first_solution_8h.html#a8555d110d9a2c60eff7eccb7b71ff8a2", null ]
];