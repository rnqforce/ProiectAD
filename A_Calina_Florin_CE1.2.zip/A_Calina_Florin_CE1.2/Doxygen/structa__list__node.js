var structa__list__node =
[
    [ "info", "structa__list__node.html#a29045c997670516117cd2d1cac1069ed", null ],
    [ "next", "structa__list__node.html#ac874548b41e8af6a71df1b2c750cf53c", null ]
];